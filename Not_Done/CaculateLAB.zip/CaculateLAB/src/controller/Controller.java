/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;
import java.util.Scanner;
import validation.Valid;

/**
 *
 * @author nguyen ngoc quang
 */
public class Controller {

    private static final Scanner in = new Scanner(System.in);
    Valid vl = new Valid();

    ArrayList<Double> arrayList = new ArrayList<>();
    
    public void addNum(double n){
        arrayList.add(n);
    }

    public ArrayList<Double> getArrayList() {
        return arrayList;
    }
    
    
    
    
    
    
    
    
    
    
//    public void superlativeEquation() {
//        System.out.println("----- Calculate Equation -----");
//        System.out.print("Enter A: ");
//        double a = vl.checkInputDouble();
//        System.out.print("Enter B: ");
//        double b = vl.checkInputDouble();
//        double x = -b / a;
//        System.out.println("Solution: x=" + x);
//        System.out.print("Number is odd: ");
//        if (vl.checkOdd(a)) {
//            System.out.print(a + " ");
//        }
//        if (vl.checkOdd(b)) {
//            System.out.print(b + " ");
//        }
//        if (vl.checkOdd(x)) {
//            System.out.print(x + " ");
//        }
//        System.out.println();
//        System.out.print("Number is even: ");
//        if (vl.checkEven(a)) {
//            System.out.print(a + " ");
//        }
//        if (vl.checkEven(b)) {
//            System.out.print(b + " ");
//        }
//        if (vl.checkEven(x)) {
//            System.out.print(x + " ");
//        }
//        System.out.println();
//        System.out.print("Number is perfect square: ");
//        if (vl.checkSquareNumber(a)) {
//            System.out.print(a + " ");
//        }
//        if (vl.checkSquareNumber(b)) {
//            System.out.print(b + " ");
//        }
//        if (vl.checkSquareNumber(x)) {
//            System.out.print(x + " ");
//        }
//        System.out.println();
//    }
//
//    //allow user calculate Quadratic Equation
//    public void quadraticEquation() {
//        System.out.println("----- Calculate Quadratic Equation -----");
//        System.out.print("Enter A: ");
//        double a = vl.checkInputDouble();
//        System.out.print("Enter B: ");
//        double b = vl.checkInputDouble();
//        System.out.print("Enter C: ");
//        double c = vl.checkInputDouble();
//        double delta = b * b - 4 * a * c;
//        double x1 = (-b + Math.sqrt(delta)) / (2 * a);
//        double x2 = (-b - Math.sqrt(delta)) / (2 * a);
//        System.out.println("Solution: x1 = " + x1 + " and x2 = " + x2);
//        System.out.print("Number is odd: ");
//        if (vl.checkOdd(a)) {
//            System.out.print(a + " ");
//        }
//        if (vl.checkOdd(b)) {
//            System.out.print(b + " ");
//        }
//        if (vl.checkOdd(c)) {
//            System.out.print(c + " ");
//        }
//        if (vl.checkOdd(x1)) {
//            System.out.print(x1 + " ");
//        }
//        if (vl.checkOdd(x2)) {
//            System.out.print(x2 + " ");
//        }
//        System.out.println();
//        System.out.print("Number is even: ");
//        if (vl.checkEven(a)) {
//            System.out.print(a + " ");
//        }
//        if (vl.checkEven(b)) {
//            System.out.print(b + " ");
//        }
//        if (vl.checkEven(c)) {
//            System.out.print(b + " ");
//        }
//        if (vl.checkEven(x1)) {
//            System.out.print(x1 + " ");
//        }
//        if (vl.checkEven(x2)) {
//            System.out.print(x1 + " ");
//        }
//        System.out.println();
//        System.out.print("Number is perfect square: ");
//        if (vl.checkSquareNumber(a)) {
//            System.out.print(a + " ");
//        }
//        if (vl.checkSquareNumber(b)) {
//            System.out.print(b + " ");
//        }
//        if (vl.checkSquareNumber(c)) {
//            System.out.print(c + " ");
//        }
//        if (vl.checkSquareNumber(x1)) {
//            System.out.print(x1 + " ");
//        }
//        if (vl.checkSquareNumber(x2)) {
//            System.out.print(x2 + " ");
//        }
//        System.out.println();
//    }
}
