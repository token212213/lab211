/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.Controller;
import validation.Valid;

/**
 *
 * @author nguyen ngoc quang
 */
public class Display {

    Valid vl = new Valid();
    Controller control = new Controller();
    
    
    public int menu() {
        System.out.println("========= Equation Program =========");
        System.out.println("1. Calculate Superlative Equation");
        System.out.println("2. Calculate Superlative Equation");
        System.out.println("3. Exit");
        int choice = vl.checkIntputIntLimit(1, 3);
        return choice;
    }

    public void DisplaySuperlativeEquation() {
        System.out.println("----- Calculate Equation -----");
        System.out.print("Enter A: ");
        double a = vl.checkInputDouble();
        System.out.print("Enter B: ");
        double b = vl.checkInputDouble();
    }

    public void superlativeEquation() {
        System.out.println("----- Calculate Equation -----");
        System.out.print("Enter A: ");
        double a = vl.checkInputDouble();
        System.out.print("Enter B: ");
        double b = vl.checkInputDouble();
        double x = -b / a;
        System.out.println("Solution: x=" + x);
        control.addNum(a);
        control.addNum(b);
        control.addNum(x);
        String list = "";
        for(int i=0; i<control.getArrayList().size();i++){
            if(vl.checkOdd(control.getArrayList().get(i))){
                System.out.print("Number is odd: ");
                System.out.print(control.getArrayList().get(i)+", ");
            }
        }
        
        //check function
//        System.out.print("Number is odd: ");
//        if (vl.checkOdd(a)) {
//            System.out.print(a + " ");
//        }
//        if (vl.checkOdd(b)) {
//            System.out.print(b + " ");
//        }
//        if (vl.checkOdd(x)) {
//            System.out.print(x + " ");
//        }
//        System.out.println();
//        System.out.print("Number is even: ");
//        if (vl.checkEven(a)) {
//            System.out.print(a + " ");
//        }
//        if (vl.checkEven(b)) {
//            System.out.print(b + " ");
//        }
//        if (vl.checkEven(x)) {
//            System.out.print(x + " ");
//        }
//        System.out.println();
//        System.out.print("Number is perfect square: ");
//        if (vl.checkSquareNumber(a)) {
//            System.out.print(a + " ");
//        }
//        if (vl.checkSquareNumber(b)) {
//            System.out.print(b + " ");
//        }
//        if (vl.checkSquareNumber(x)) {
//            System.out.print(x + " ");
//        }
//        System.out.println();
    }

    public void quadraticEquation() {
        //calculate
        System.out.println("----- Calculate Quadratic Equation -----");
        System.out.print("Enter A: ");
        double a = vl.checkInputDouble();
        System.out.print("Enter B: ");
        double b = vl.checkInputDouble();
        System.out.print("Enter C: ");
        double c = vl.checkInputDouble();
        double delta = b * b - 4 * a * c;
        double x1 = (-b + Math.sqrt(delta)) / (2 * a);
        double x2 = (-b - Math.sqrt(delta)) / (2 * a);
        System.out.println("Solution: x1 = " + x1 + " and x2 = " + x2);
        
        //check function
//        System.out.print("Number is odd: ");
//        if (vl.checkOdd(a)) {
//            System.out.print(a + " ");
//        }
//        if (vl.checkOdd(b)) {
//            System.out.print(b + " ");
//        }
//        if (vl.checkOdd(c)) {
//            System.out.print(c + " ");
//        }
//        if (vl.checkOdd(x1)) {
//            System.out.print(x1 + " ");
//        }
//        if (vl.checkOdd(x2)) {
//            System.out.print(x2 + " ");
//        }
//        System.out.println();
//        System.out.print("Number is even: ");
//        if (vl.checkEven(a)) {
//            System.out.print(a + " ");
//        }
//        if (vl.checkEven(b)) {
//            System.out.print(b + " ");
//        }
//        if (vl.checkEven(c)) {
//            System.out.print(b + " ");
//        }
//        if (vl.checkEven(x1)) {
//            System.out.print(x1 + " ");
//        }
//        if (vl.checkEven(x2)) {
//            System.out.print(x1 + " ");
//        }
        System.out.println();
        System.out.print("Number is perfect square: ");
        if (vl.checkSquareNumber(a)) {
            System.out.print(a + " ");
        }
        if (vl.checkSquareNumber(b)) {
            System.out.print(b + " ");
        }
        if (vl.checkSquareNumber(c)) {
            System.out.print(c + " ");
        }
        if (vl.checkSquareNumber(x1)) {
            System.out.print(x1 + " ");
        }
        if (vl.checkSquareNumber(x2)) {
            System.out.print(x2 + " ");
        }
        System.out.println();
    }
}
